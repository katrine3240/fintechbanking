package main

import "accenture.com/banking/api"

func main() {
	api.StartApi()
}
