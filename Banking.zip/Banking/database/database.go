package database

import (
	"accenture.com/banking/helpers"
	"github.com/jinzhu/gorm"
)

var DB *gorm.DB

func InitDatabase() {
	database, err := gorm.Open("postgres", "host=ec2-44-210-228-110.compute-1.amazonaws.com port=5432 user=ncpvngblfasywq dbname=d8rr74sacrn6sr password=8e1a0f7b48cac4029c03fce254722451bf164730d1230270c5036869d66de11c sslmode=required")
	helpers.HandleErr(err)
	database.DB().SetMaxIdleConns(20)
	database.DB().SetMaxOpenConns(200)
	DB = database
}
